var struct_r_f_c___d_a_t_a___c_o_n_t_a_i_n_e_r =
[
    [ "handle", "struct_r_f_c___d_a_t_a___c_o_n_t_a_i_n_e_r.html#a3b01b057592e7949a10f065763ef5122", null ]
];