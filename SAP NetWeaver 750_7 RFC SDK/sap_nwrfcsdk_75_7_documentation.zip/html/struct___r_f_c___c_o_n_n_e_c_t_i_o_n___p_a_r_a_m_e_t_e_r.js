var struct___r_f_c___c_o_n_n_e_c_t_i_o_n___p_a_r_a_m_e_t_e_r =
[
    [ "name", "struct___r_f_c___c_o_n_n_e_c_t_i_o_n___p_a_r_a_m_e_t_e_r.html#ab9ee37f3a03f41a4b2720d2acb0a1546", null ],
    [ "value", "struct___r_f_c___c_o_n_n_e_c_t_i_o_n___p_a_r_a_m_e_t_e_r.html#a3f32db2848d8c8896cbda8208ed5fa7b", null ]
];