var struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c =
[
    [ "decimals", "struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#a8bb58f31bc0dd1e704cb32edaa091f72", null ],
    [ "defaultValue", "struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#a50719e36aadf318025750e4340ce87ec", null ],
    [ "direction", "struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#a9eda6f1b3ee6404c592c2ac5c0d18c2e", null ],
    [ "extendedDescription", "struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#af0f2a99370a4c387ee0d9725d67e646a", null ],
    [ "name", "struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#a82e74b0c00c1a74458168124616cb112", null ],
    [ "nucLength", "struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#afab3aa38a2765ff7b2d8ebdf8715aead", null ],
    [ "optional", "struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#a7cb8ff4e643f938ab274df2f4f14d634", null ],
    [ "parameterText", "struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#acef68da4f72043a26a33a8c4aabdee9c", null ],
    [ "type", "struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#a8175e09cfb3b96993af74b5e40e46031", null ],
    [ "typeDescHandle", "struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#adb6617f3817e79137592ebd3a56008cb", null ],
    [ "ucLength", "struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#a383a6c0487612b883289272f52c3a854", null ]
];