var struct___r_f_c___t_y_p_e___d_e_s_c___h_a_n_d_l_e =
[
    [ "handle", "struct___r_f_c___t_y_p_e___d_e_s_c___h_a_n_d_l_e.html#a55d88ccc160a32cf2b96ea99e6a47d01", null ]
];