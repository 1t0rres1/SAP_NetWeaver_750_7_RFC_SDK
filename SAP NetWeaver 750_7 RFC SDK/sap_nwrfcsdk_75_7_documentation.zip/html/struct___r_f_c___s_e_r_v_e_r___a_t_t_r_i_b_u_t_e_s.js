var struct___r_f_c___s_e_r_v_e_r___a_t_t_r_i_b_u_t_e_s =
[
    [ "currentBusyCount", "struct___r_f_c___s_e_r_v_e_r___a_t_t_r_i_b_u_t_e_s.html#a80ae1ac8f5e2bbeb33094bf545401ccf", null ],
    [ "peakBusyCount", "struct___r_f_c___s_e_r_v_e_r___a_t_t_r_i_b_u_t_e_s.html#a03298084d183eb4f070dbbf0ec10873e", null ],
    [ "registrationCount", "struct___r_f_c___s_e_r_v_e_r___a_t_t_r_i_b_u_t_e_s.html#a96cd6e750dbe4df68266fbd5a3dd878e", null ],
    [ "serverName", "struct___r_f_c___s_e_r_v_e_r___a_t_t_r_i_b_u_t_e_s.html#ac8d3c6092a083507bc086063ffba4863", null ],
    [ "state", "struct___r_f_c___s_e_r_v_e_r___a_t_t_r_i_b_u_t_e_s.html#a3e2a203abebaa1be07bd8c1a495f08ce", null ],
    [ "type", "struct___r_f_c___s_e_r_v_e_r___a_t_t_r_i_b_u_t_e_s.html#a31e80e7bcf1f36cfa1c58486ba05aba6", null ]
];