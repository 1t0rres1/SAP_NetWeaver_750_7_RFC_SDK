var doxyfile__nrfc__public_8h =
[
    [ "FALSE", "doxyfile__nrfc__public_8h.html#aa93f0eb578d23995850d61f7d61c55c1", null ],
    [ "SAP_O_K", "doxyfile__nrfc__public_8h.html#a9ecab66718e0e86b6614bb1a83d05774", null ],
    [ "TRUE", "doxyfile__nrfc__public_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d", null ],
    [ "SAP_BOOL", "doxyfile__nrfc__public_8h.html#a0cbcc899af5e2ac6faac2ea3d14deb0d", null ],
    [ "SAP_INT", "doxyfile__nrfc__public_8h.html#ad9955843391c7ebc8e6da51b4185e53e", null ],
    [ "SAP_RAW", "doxyfile__nrfc__public_8h.html#aff64b806fdd97994b70850be3a68e786", null ],
    [ "SAP_SHORT", "doxyfile__nrfc__public_8h.html#ac5f8edc2e1efb84fcc613fc9b36fee5c", null ],
    [ "SAP_UC", "doxyfile__nrfc__public_8h.html#ae16eacfd4e9786894791ecd60e195e75", null ],
    [ "SAP_UINT", "doxyfile__nrfc__public_8h.html#a1faca29a99f6f25b5eaaf9aaee449066", null ],
    [ "SAP_USHORT", "doxyfile__nrfc__public_8h.html#a16e21ac8f4b515f92690c56c90690f4b", null ],
    [ "SAPRETURN", "doxyfile__nrfc__public_8h.html#aa66bc69827daaa70d4952638c84e0245", null ]
];