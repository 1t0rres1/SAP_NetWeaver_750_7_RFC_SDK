var struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c =
[
    [ "attributeType", "struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#a85276a2110fab5732839f0ae73d7a118", null ],
    [ "decimals", "struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#ab308be8c208ae4e5f3372e2822047ae8", null ],
    [ "declaringClass", "struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#ae267a92be2a3dc3db9f92e616b7c5cd8", null ],
    [ "defaultValue", "struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#a003d29c09331cee8aa4e090701cf3c2e", null ],
    [ "description", "struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#aa47a6dc8323e364cb87aae489052d838", null ],
    [ "extendedDescription", "struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#a840af76b41f2dda7efd7adaf409a1304", null ],
    [ "isReadOnly", "struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#a1d84ef9a2a9bd5336cf81fc9411a296d", null ],
    [ "name", "struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#acc5d96f25a21842af858a77e4e81fb00", null ],
    [ "nucLength", "struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#a4053f73333becaee080d3e87fe0c1e45", null ],
    [ "type", "struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#a2c5481818031f7f0dbbc45feccdda43a", null ],
    [ "typeDescHandle", "struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#ac26bfc62adb11549889aef21dbcadff6", null ],
    [ "ucLength", "struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#a193e8965f94e18cbec4a1d823b8c3643", null ]
];