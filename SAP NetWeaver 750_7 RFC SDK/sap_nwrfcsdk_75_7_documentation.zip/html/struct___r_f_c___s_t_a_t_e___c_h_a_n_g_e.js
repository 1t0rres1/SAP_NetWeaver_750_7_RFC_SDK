var struct___r_f_c___s_t_a_t_e___c_h_a_n_g_e =
[
    [ "newState", "struct___r_f_c___s_t_a_t_e___c_h_a_n_g_e.html#af7334661721924ce800a87848fdfbf31", null ],
    [ "oldState", "struct___r_f_c___s_t_a_t_e___c_h_a_n_g_e.html#a2c352e9384f8b5aa9dd60c49acab7d27", null ]
];