var struct___r_f_c___u_n_i_t___i_d_e_n_t_i_f_i_e_r =
[
    [ "unitID", "struct___r_f_c___u_n_i_t___i_d_e_n_t_i_f_i_e_r.html#ab3ff02a61130173131162d0ceb1b611d", null ],
    [ "unitType", "struct___r_f_c___u_n_i_t___i_d_e_n_t_i_f_i_e_r.html#a22fc5880b32cc1f79143fd59dd80b746", null ]
];