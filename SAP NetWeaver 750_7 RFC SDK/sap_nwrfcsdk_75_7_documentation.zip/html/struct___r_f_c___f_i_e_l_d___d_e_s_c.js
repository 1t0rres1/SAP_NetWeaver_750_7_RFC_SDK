var struct___r_f_c___f_i_e_l_d___d_e_s_c =
[
    [ "decimals", "struct___r_f_c___f_i_e_l_d___d_e_s_c.html#a6a67335ebe0de61dd38f85d10d635dd7", null ],
    [ "extendedDescription", "struct___r_f_c___f_i_e_l_d___d_e_s_c.html#a75c7afde51a50480913b9bdfb8e6493a", null ],
    [ "name", "struct___r_f_c___f_i_e_l_d___d_e_s_c.html#a4f36616cc505e6121acfa3bcc5efda69", null ],
    [ "nucLength", "struct___r_f_c___f_i_e_l_d___d_e_s_c.html#a13026076ca13aac0df68b37cc7db4de5", null ],
    [ "nucOffset", "struct___r_f_c___f_i_e_l_d___d_e_s_c.html#a5b952a9c96dae8d7ee7ef9915b8a0281", null ],
    [ "type", "struct___r_f_c___f_i_e_l_d___d_e_s_c.html#a7dc53826d63143bf1f809a59383a9acb", null ],
    [ "typeDescHandle", "struct___r_f_c___f_i_e_l_d___d_e_s_c.html#a859f44444ad64d816a866646984dc6a4", null ],
    [ "ucLength", "struct___r_f_c___f_i_e_l_d___d_e_s_c.html#a418fcab863e30aebad9584907c18f1a3", null ],
    [ "ucOffset", "struct___r_f_c___f_i_e_l_d___d_e_s_c.html#a4becc4d7e665627035fb681f53eb755b", null ]
];