var struct___r_f_c___s_e_r_v_e_r___h_a_n_d_l_e =
[
    [ "handle", "struct___r_f_c___s_e_r_v_e_r___h_a_n_d_l_e.html#ae1df9c1f9d1707eda5d5b8c0920e77ca", null ]
];