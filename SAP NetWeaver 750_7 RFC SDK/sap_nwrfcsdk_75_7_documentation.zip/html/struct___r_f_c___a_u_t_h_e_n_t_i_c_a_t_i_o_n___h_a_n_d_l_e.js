var struct___r_f_c___a_u_t_h_e_n_t_i_c_a_t_i_o_n___h_a_n_d_l_e =
[
    [ "handle", "struct___r_f_c___a_u_t_h_e_n_t_i_c_a_t_i_o_n___h_a_n_d_l_e.html#aa5b266f0ccc9036de4eacb977a01463b", null ]
];