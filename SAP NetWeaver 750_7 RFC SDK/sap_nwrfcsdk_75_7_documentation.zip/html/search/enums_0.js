var searchData=
[
  ['_5frfc_5fauthentication_5ftype',['_RFC_AUTHENTICATION_TYPE',['../group__autoserver.html#gac12eb9d08fc4d5cd0cfd9f9fc76e7464',1,'sapnwrfc.h']]],
  ['_5frfc_5fcall_5ftype',['_RFC_CALL_TYPE',['../group__connection.html#ga7d7f6b124829f02177a13f91ef3074b3',1,'sapnwrfc.h']]],
  ['_5frfc_5fclass_5fattribute_5ftype',['_RFC_CLASS_ATTRIBUTE_TYPE',['../group__repository.html#ga04c40d0e9afb7823acb50656f46b23a8',1,'sapnwrfc.h']]],
  ['_5frfc_5fdirection',['_RFC_DIRECTION',['../group__repository.html#ga4b85a6820d7a732230a422716103629a',1,'sapnwrfc.h']]],
  ['_5frfc_5ferror_5fgroup',['_RFC_ERROR_GROUP',['../group__api.html#ga497758475b7ea26a55501399ec03a2e6',1,'sapnwrfc.h']]],
  ['_5frfc_5fmetadata_5fobj_5ftype',['_RFC_METADATA_OBJ_TYPE',['../group__repository.html#gaa1943d7548a39e8e054c68294724836f',1,'sapnwrfc.h']]],
  ['_5frfc_5fprotocol_5ftype',['_RFC_PROTOCOL_TYPE',['../group__connection.html#ga92d7f99e875e511d9b7c6a440bd42c78',1,'sapnwrfc.h']]],
  ['_5frfc_5frc',['_RFC_RC',['../group__api.html#gaa5fa7b6f0bbfe64eeb72982276e2aa2e',1,'sapnwrfc.h']]],
  ['_5frfc_5fserver_5fstate',['_RFC_SERVER_STATE',['../group__autoserver.html#ga975bded614b016506fa5ac8524706d2a',1,'sapnwrfc.h']]],
  ['_5frfc_5fsession_5fevent',['_RFC_SESSION_EVENT',['../group__autoserver.html#gaf3160255a9f929f3f211baf6de92b2fd',1,'sapnwrfc.h']]],
  ['_5frfc_5funit_5fstate',['_RFC_UNIT_STATE',['../group__bgrfc.html#gaebc108b79a2a5d68080c44cf0db31565',1,'sapnwrfc.h']]],
  ['_5frfctype',['_RFCTYPE',['../group__api.html#gac58fcff3767afdd89df80b2a9724d9c7',1,'sapnwrfc.h']]]
];
