var searchData=
[
  ['external_5fapplication_5ffailure',['EXTERNAL_APPLICATION_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6a9caa0231be888ebf92a708f6df13f8a3',1,'sapnwrfc.h']]],
  ['external_5fauthentication_5ffailure',['EXTERNAL_AUTHENTICATION_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6ac4ae691ef701ca72ea587f18bd4505b8',1,'sapnwrfc.h']]],
  ['external_5fauthorization_5ffailure',['EXTERNAL_AUTHORIZATION_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6a202cc24d3b7760c4b6b874297e0aaa75',1,'sapnwrfc.h']]],
  ['external_5fruntime_5ffailure',['EXTERNAL_RUNTIME_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6af4f6dff366d5989456eb5aeafcfefee2',1,'sapnwrfc.h']]]
];
