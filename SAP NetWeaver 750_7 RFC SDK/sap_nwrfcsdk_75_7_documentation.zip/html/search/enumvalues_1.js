var searchData=
[
  ['abap_5fapplication_5ffailure',['ABAP_APPLICATION_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6a2012cb14e032dea966ae44aaaa97ebc2',1,'sapnwrfc.h']]],
  ['abap_5fruntime_5ffailure',['ABAP_RUNTIME_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6a8ea73efa73dec715ac5f04dabb968643',1,'sapnwrfc.h']]]
];
