var searchData=
[
  ['public_20api',['Public API',['../group__api.html',1,'']]],
  ['p_5f_5frfc_5fexception_5fdesc',['P__RFC_EXCEPTION_DESC',['../sapnwrfc_8h.html#a0c04d329dcc0cd1e9ffb3fca38bcdeeb',1,'sapnwrfc.h']]],
  ['p_5frfc_5fattributes',['P_RFC_ATTRIBUTES',['../sapnwrfc_8h.html#abe1944f091e8c5e21e76a7e3bf0acadc',1,'sapnwrfc.h']]],
  ['p_5frfc_5fclass_5fattribute_5fdesc',['P_RFC_CLASS_ATTRIBUTE_DESC',['../sapnwrfc_8h.html#aebaf41cbdd0aa883c4758969cdddf137',1,'sapnwrfc.h']]],
  ['p_5frfc_5fconnection_5fparameter',['P_RFC_CONNECTION_PARAMETER',['../sapnwrfc_8h.html#aacc0a7bceecc982f6a9f39cb4da2ba67',1,'sapnwrfc.h']]],
  ['p_5frfc_5ffield_5fdesc',['P_RFC_FIELD_DESC',['../sapnwrfc_8h.html#a6429db7bbc7d68cb28918a139b0f52ac',1,'sapnwrfc.h']]],
  ['p_5frfc_5fparameter_5fdesc',['P_RFC_PARAMETER_DESC',['../sapnwrfc_8h.html#a1d304615be362a10c2da9df56385d1de',1,'sapnwrfc.h']]],
  ['p_5frfc_5fsecurity_5fattributes',['P_RFC_SECURITY_ATTRIBUTES',['../sapnwrfc_8h.html#a985ad3e6f8cff7a98ca9d3d0b2ac9eeb',1,'sapnwrfc.h']]],
  ['parametertext',['parameterText',['../struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#acef68da4f72043a26a33a8c4aabdee9c',1,'_RFC_PARAMETER_DESC']]],
  ['partnerbytesperchar',['partnerBytesPerChar',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a321c5b7c3a8471e9a74ae252824378d1',1,'_RFC_ATTRIBUTES']]],
  ['partnercodepage',['partnerCodepage',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#aec2e78f82ee5c3d800eecad38b228e5e',1,'_RFC_ATTRIBUTES']]],
  ['partnerhost',['partnerHost',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a508cb905e22875779ebf7df7b316eb1d',1,'_RFC_ATTRIBUTES']]],
  ['partnerip',['partnerIP',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a296bc8d12035708fb178c2860433e29d',1,'_RFC_ATTRIBUTES']]],
  ['partneripv6',['partnerIPv6',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#aee6ab45062f5658c4fb69dae5860c232',1,'_RFC_ATTRIBUTES']]],
  ['partnerrel',['partnerRel',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#ae3c283f065e9523744096f081eaeac66',1,'_RFC_ATTRIBUTES']]],
  ['partnersystemcodepage',['partnerSystemCodepage',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a45205858adb01b29ad63e11dfd8b74de',1,'_RFC_ATTRIBUTES']]],
  ['partnertype',['partnerType',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a5552895ebd47c6aed28a8600bda1093d',1,'_RFC_ATTRIBUTES']]],
  ['peakbusycount',['peakBusyCount',['../struct___r_f_c___s_e_r_v_e_r___a_t_t_r_i_b_u_t_e_s.html#a03298084d183eb4f070dbbf0ec10873e',1,'_RFC_SERVER_ATTRIBUTES']]],
  ['progname',['progName',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#ad9f03d64a9d26b5b778ff8462e0ba870',1,'_RFC_ATTRIBUTES::progName()'],['../struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a73c1cb8b9aeaa112bcb39bbf499814c3',1,'_RFC_SECURITY_ATTRIBUTES::progName()']]],
  ['program',['program',['../struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#ab9ec4b21c8dbf3e38527fc2c0477392f',1,'_RFC_UNIT_ATTRIBUTES']]]
];
