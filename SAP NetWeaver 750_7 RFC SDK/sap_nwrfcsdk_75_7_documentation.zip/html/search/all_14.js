var searchData=
[
  ['uclength',['ucLength',['../struct___r_f_c___f_i_e_l_d___d_e_s_c.html#a418fcab863e30aebad9584907c18f1a3',1,'_RFC_FIELD_DESC::ucLength()'],['../struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#a383a6c0487612b883289272f52c3a854',1,'_RFC_PARAMETER_DESC::ucLength()'],['../struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#a193e8965f94e18cbec4a1d823b8c3643',1,'_RFC_CLASS_ATTRIBUTE_DESC::ucLength()']]],
  ['ucoffset',['ucOffset',['../struct___r_f_c___f_i_e_l_d___d_e_s_c.html#a4becc4d7e665627035fb681f53eb755b',1,'_RFC_FIELD_DESC']]],
  ['unitattributes',['unitAttributes',['../struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#ae2acb7f8330409986df568236cb3a737',1,'_RFC_SERVER_CONTEXT']]],
  ['unithistory',['unitHistory',['../struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#ae1c21b150c419b2f920472f7b5526064',1,'_RFC_UNIT_ATTRIBUTES']]],
  ['unitid',['unitID',['../struct___r_f_c___u_n_i_t___i_d_e_n_t_i_f_i_e_r.html#ab3ff02a61130173131162d0ceb1b611d',1,'_RFC_UNIT_IDENTIFIER']]],
  ['unitidentifier',['unitIdentifier',['../struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#a7ff76c4728c04654781c70659f6aeb27',1,'_RFC_SERVER_CONTEXT']]],
  ['unittype',['unitType',['../struct___r_f_c___u_n_i_t___i_d_e_n_t_i_f_i_e_r.html#a22fc5880b32cc1f79143fd59dd80b746',1,'_RFC_UNIT_IDENTIFIER']]],
  ['user',['user',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a64cf4508db46a45836272117d90f06ae',1,'_RFC_ATTRIBUTES::user()'],['../struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a612941028fb8bf5cc4931a75969757f3',1,'_RFC_SECURITY_ATTRIBUTES::user()'],['../struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#a830c2fbe313993ecfbb8191a905c2181',1,'_RFC_UNIT_ATTRIBUTES::user()']]]
];
