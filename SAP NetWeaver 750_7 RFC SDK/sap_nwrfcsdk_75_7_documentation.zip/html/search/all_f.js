var searchData=
[
  ['ok',['OK',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6a2bc49ec37d6a5715dd23e85f1ff5bb59',1,'sapnwrfc.h']]],
  ['oldstate',['oldState',['../struct___r_f_c___s_t_a_t_e___c_h_a_n_g_e.html#a2c352e9384f8b5aa9dd60c49acab7d27',1,'_RFC_STATE_CHANGE']]],
  ['optional',['optional',['../struct___r_f_c___p_a_r_a_m_e_t_e_r___d_e_s_c.html#a7cb8ff4e643f938ab274df2f4f14d634',1,'_RFC_PARAMETER_DESC']]]
];
