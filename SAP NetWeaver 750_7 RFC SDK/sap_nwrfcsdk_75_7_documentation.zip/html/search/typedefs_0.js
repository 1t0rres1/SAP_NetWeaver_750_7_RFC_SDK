var searchData=
[
  ['data_5fcontainer_5fhandle',['DATA_CONTAINER_HANDLE',['../sapnwrfc_8h.html#a0d98f220063d17aab25ac5639d81dd3f',1,'sapnwrfc.h']]]
];
