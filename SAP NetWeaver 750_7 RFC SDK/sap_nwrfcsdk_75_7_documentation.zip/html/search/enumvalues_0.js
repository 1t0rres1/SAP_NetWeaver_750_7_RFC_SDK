var searchData=
[
  ['_5frfc_5frc_5fmax_5fvalue',['_RFC_RC_max_value',['../sapnwrfc_8h.html#gaa5fa7b6f0bbfe64eeb72982276e2aa2ea3593c3b04e32a086e3a619a5572f8776',1,'sapnwrfc.h']]],
  ['_5frfctype_5fmax_5fvalue',['_RFCTYPE_max_value',['../sapnwrfc_8h.html#gac58fcff3767afdd89df80b2a9724d9c7a1681c6692e8db3c24a3054b3d1704793',1,'sapnwrfc.h']]]
];
