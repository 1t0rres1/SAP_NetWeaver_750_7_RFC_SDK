var searchData=
[
  ['communication_5ffailure',['COMMUNICATION_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6a41d6abb3e5d6782202ec19b2c9572c97',1,'sapnwrfc.h']]]
];
