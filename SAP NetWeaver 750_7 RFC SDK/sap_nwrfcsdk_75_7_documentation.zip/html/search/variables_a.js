var searchData=
[
  ['message',['message',['../struct___r_f_c___e_r_r_o_r___i_n_f_o.html#a42a530e1c629e94a5e7b0529c42553bf',1,'_RFC_ERROR_INFO::message()'],['../struct___r_f_c___e_x_c_e_p_t_i_o_n___d_e_s_c.html#ae464627f568cc6750f4400d420b2b4db',1,'_RFC_EXCEPTION_DESC::message()']]]
];
