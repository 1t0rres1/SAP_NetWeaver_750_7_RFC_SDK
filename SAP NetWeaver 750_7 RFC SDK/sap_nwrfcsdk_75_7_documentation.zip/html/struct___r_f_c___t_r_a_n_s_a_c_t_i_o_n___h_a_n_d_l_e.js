var struct___r_f_c___t_r_a_n_s_a_c_t_i_o_n___h_a_n_d_l_e =
[
    [ "handle", "struct___r_f_c___t_r_a_n_s_a_c_t_i_o_n___h_a_n_d_l_e.html#adc77d96b032f332f9e4a4ae98f80e707", null ]
];