var files =
[
    [ "doxyfile_nrfc_public.h", "doxyfile__nrfc__public_8h.html", "doxyfile__nrfc__public_8h" ],
    [ "sapnwrfc.h", "sapnwrfc_8h.html", "sapnwrfc_8h" ]
];