var globals_func =
[
    [ "r", "globals_func.html", null ]
];